
import React, { useState, useEffect } from "react";
import axios from 'axios';
import './barcodecss.css'; 
import CapPlanFilter from './CapPlanFilter.js';

import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";

// rest of the imports

function Tables() {
  const [tbdata, setTbdata] = useState([]);
  const [basedata, setBasedata] = useState([]);
  const [err, setErr] = useState(0);
  const [isDone, setIsDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [unqPlant, setUnqPlant] = useState([]);
  const [unqTechnology, setUnqTechnology] = useState([]);
  const [selectedPlant, setSelectedPlant] = useState([]);
  const [selectedTechnology, setSelectedTechnology] = useState([]);
  const [unqMainValving, setUnqMainValving] = useState([]);
  const [unqRod, setUnqRod] = useState([]);
  const [unqPT, setUnqPT] = useState([]);
  const [selectedMainValving, setSelectedMainValving] = useState([]);
  const [selectedRod, setSelectedRod] = useState([]);
  const [selectedPT, setSelectedPT] = useState([]);
  const [stationCheck1, setStationCheck1] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState({
    plant: "",
    technology: "",
    mainValving: "",
    rod: "",
    pt:"",
  })
   
  

  const handleCheckboxChange = (index) => {
    setTbdata((prevData) => {
      const newData = [...prevData];
      newData[index].stationCheck1 = !newData[index].stationCheck1;

      // Set CT to null only for the row where the checkbox is checked
      if (newData[index].stationCheck1) {
        // Store the original CT value before setting it to null
        newData[index].originalCT = newData[index].CT;
        newData[index].CT = null;
      } else {
        // Retrieve the original CT value when the checkbox is unchecked
        newData[index].CT = newData[index].originalCT;
        // Clear the stored original CT value
        delete newData[index].originalCT;
      }

      return newData;
    });
  };

 


  const filterPlantCallback = (selPlant) => {
    console.log(selPlant.val);
    setSelectedPlant(selPlant.val);
    setSelectedFilter((prevFilters)=>({...prevFilters, plant:selPlant.val}));
  };
  
   const filterMainValvingCallback = (selMainValving) => {
    console.log(selMainValving.val);
    setSelectedMainValving(selMainValving.val);
    setSelectedFilter((prevFilters)=>({...prevFilters, mainValving:selMainValving.val}));
  };

  const filterRodCallback = (selRod) => {
    console.log(selRod.val);
    setSelectedRod(selRod.val);
    setSelectedFilter((prevFilters)=>({...prevFilters, rod:selRod.val}));
  };

  const filterPTCallback = (selPT) => {
    console.log(selPT.val);
    setSelectedPT(selPT.val);
    setSelectedFilter((prevFilters)=>({...prevFilters, pt:selPT.val}));
  };
     
  const filterTechnologyCallback = (selTechnology) => {
    console.log(selTechnology.val);
    setSelectedTechnology(selTechnology.val);
    setSelectedFilter((prevFilters)=>({...prevFilters, technology:selTechnology.val}));
  };
    

  useEffect(() => {
    let regexPlant = new RegExp([`^${selectedPlant}`], "i");
    let regexMainValving = new RegExp([`^${selectedMainValving}`], "i");
    let regexRod = new RegExp([`^${selectedRod}`], "i");
    let regexPT = new RegExp([`^${selectedPT}`], "i");
    let regexTechnology = new RegExp([`^${selectedTechnology}`], "i");

    setTbdata(
      basedata.filter((val) => {
        return (
          regexPlant.test(val.Plant) &&
          regexMainValving.test(val.MainValving) &&
          regexRod.test(val.Rod) &&
          regexPT.test(val.PT) &&
          regexTechnology.test(val.Technology) 
        );
      })
    );
  }, [selectedPlant, selectedMainValving, selectedRod, selectedPT, selectedTechnology]);

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/capApi/Capacity/")
      .then((response) => {
        setBasedata(response.data);
        setTbdata(response.data);
        setLoading(false);
        setIsDone(true);

       
        let uniquePlants = new Set(response.data.map((val) => val.Plant));
        let uniqueMainValving = new Set(response.data.map((val) => val.MainValving));
        let uniqueRod = new Set(response.data.map((val) => val.Rod));
        let uniquePT = new Set(response.data.map((val) => val.PT));
        let uniqueTechnologies = new Set(response.data.map((val) => val.Technology));

        setUnqPlant(Array.from(uniquePlants));
        setUnqMainValving(Array.from(uniqueMainValving));
        setUnqRod(Array.from(uniqueRod));
        setUnqPT(Array.from(uniquePT));
        setUnqTechnology(Array.from(uniqueTechnologies));

        console.log(response.data);
      })
      .catch((error) => {
        setErr(error);
        console.log(error);
        setLoading(false);
      });
  }, []);

  const showData = () => {
    let sum = 0;
    const reqData = tbdata.map((row, i) => {
      const ctValue = parseInt(row.CT, 10);
      if(!isNaN(ctValue))
      {
        sum+=ctValue;
      }   
       return (
        <tr key={row.EQID + row.Plant + i}>
        <td>{row.id}</td>
        <td>{row.Plant}</td>
        <td>{row.Phase}</td>
        <td>{row.Process}</td>
        <td>{row.Line}</td>
        <td>{row.CostCenter}</td>
        <td>
            <input
              type="checkbox"
              id={`stationCheck${i}`}
              name={`stationCheck${i}`}
              value={`optionChecked${i}`}
              onChange={() => handleCheckboxChange(i)}
              checked={row.stationCheck1 || false}
            />
            <label htmlFor={`stationCheck${i}`}>Option</label>
          </td>
        <td>{row.stationCheck1 ? null : row.CT}</td>
        {/* <td> 
          <input type="checkbox" id="stationCheck1" name="stationCheck1" value="optionChecked1" onChange={(e)=>setStationCheck1(e.target.checked)} checked={stationCheck1}/>
          <label for="stationCheck1">Option</label>
        </td> */}

        {/* <td>{stationCheck1 ? row.CT : null}</td>    has     */}
        {/* <td>{row.CT}</td> */}
        <td>{row.Capacity}</td>
        <td>{row.WorkCenter}</td>
        <td>{row.Equipment}</td>
        <td>{row.EQID}</td>
        <td>{row.Technology}</td>
        <td>{row.MainValving}</td>
        <td>{row.Rod}</td>
        <td>{row.PT}</td>
      </tr>
     );
    });

    // Add the row for the sum at the end of the column
    reqData.push(
      <tr key="sum">
        <td></td> {/* Empty cell corresponding to the checkbox column */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td></td> {/* Empty cell corresponding to the CT values */}
        <td>Sum: {sum}</td> {/* Display the sum at the end of the column */}
        {/* ... (other empty cells corresponding to other columns) */}
      </tr>
    );

    return reqData;
  };

  return (
    <React.Fragment>
      <CapPlanFilter
        plant={unqPlant}
        mainValving={unqMainValving}
        rod={unqRod}
        pt={unqPT}        
        technology={unqTechnology}
        filterPlantCallback={filterPlantCallback}
        filterMainValvingCallback={filterMainValvingCallback}
        filterRodCallback={filterRodCallback}
        filterPTCallback={filterPTCallback}        
        filterTechnologyCallback={filterTechnologyCallback}
      />

<div className="content">
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">CapacityPlanning</CardTitle>
              </CardHeader>
              <CardBody>
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                    <th className="text-center">ID</th>
                    <th className="text-center">Plant</th>
                    <th className="text-center">Phase</th>
                    <th className="text-center">Process</th>
                    <th className="text-center">Line</th>
                    <th className="text-center">CostCenter</th>
                    <th className="text-center">Station Check</th>
                    <th className="text-center">CT</th>
                    <th className="text-center">Capacity</th>	
                    <th className="text-center">WorkCenter</th>
                    <th className="text-center">Equipment</th>
                    <th className="text-center">EQID</th>
                    <th className="text-center">Technology</th>
                    <th className="text-center">MainValving</th>
                    <th className="text-center">Rod</th>
                    <th className="text-center">PT</th>
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    {console.log(isDone)}
                    {isDone ? showData() : null}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </React.Fragment>
  );
}

export default Tables;



