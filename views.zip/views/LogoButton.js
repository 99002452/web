// LogoButton.js
import React from 'react';
import { Link } from 'react-router-dom';
import logoImage from './apple-icon.png'; // Import your logo image
import logoImage2 from './home.png';
import logoImage3 from './sales.png';


const LogoButton = ({ to, alt, className }) => {
  return (
    <Link to={to} className={className}>
      <img src={logoImage} alt={alt} />
      {/* <img src2={logoImage2} alt={alt} />
      <img src3S={logoImage3} alt={alt} /> */}
    </Link>
    
  );
};

export default LogoButton;