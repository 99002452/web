/*!

=========================================================
* Black Dashboard React v1.2.2
=========================================================

* Product Page: https://www.creative-tim.com/product/black-dashboard-react
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Licensed under MIT (https://github.com/creativetimofficial/black-dashboard-react/blob/master/LICENSE.md)

* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

*/
import BopTemplate from "views/BopTemplate.js";
import BopTemplateNew from "views/BopTemplateNew.js";
import CapacityPlanning from "views/CapacityPlanning.js";
import CapPlanFilter from "views/CapPlanFilter.js";
import SaleforceTable from "views/SaleforceTable.js";
// import TableList from "views/TableList.js";
// import Typography from "views/Typography.js";
// import UserProfile from "views/UserProfile.js";

var routes = [
  {
    path: "/BopTemplate",
    name: "BopTemplate",
    rtlName: "لوحة القيادة",
    icon: "tim-icons icon-chart-pie-36",
    component: <BopTemplate />,
    layout: "/admin",
  },
  {
    path: "/BopTemplateNew",
    name: "Bop Template New",
    rtlName: "الرموز",
    icon: "tim-icons icon-atom",
    component: <BopTemplateNew />,
    layout: "/admin",
  },


  {
    path: "/salesforce",
    name: "Saleforce",
    rtlName: "قائمة الجدول",
    icon: "tim-icons icon-puzzle-10",
    component: <SaleforceTable/>,
    layout: "/admin",
  },
  {
    path: "/CapacityPlanning",
    name: "CapacityPlanning",
    rtlName: "طباعة",
    icon: "tim-icons icon-align-center",
    component: <CapacityPlanning />,
    layout: "/admin",
  },
 
];
export default routes;
