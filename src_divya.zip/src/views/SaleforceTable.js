
import React, { useState, useEffect } from "react";
import axios from 'axios';


// reactstrap components
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  Table,
  Row,
  Col,
} from "reactstrap";




function Tables() {
//  const initialData=[{date:null,barcode_data:null, counter:null}]
 const [tbdata, setTbdata]=useState([]);
 const [err, seterr]=useState(0);
 const [isDone, setIsDone]=useState(false);
 const [loading, setLoading]=useState(false);

 

 useEffect(()=>{
  (console.log("HI"))
  //  fetchData();

        axios.get('http://127.0.0.1:8000/SaleforceApi/SalesforceData/')
        .then (response => {setTbdata(response.data);
          setLoading(false);
          setIsDone(true);
          
        console.log(response.data);})
    .catch(error=>{seterr(error);console.log(error); setLoading(false)})
    

 },[])
 
 

 const showData=()=>
 {
 const reqData=tbdata.map(row=>{
    return(
      <tr key={row.id} >
        
        <td>{row.id}</td>
        <td>{row.PlatformText}</td>
        <td>{row.ProgramText}</td>
        <td>{row.MountingLocation}</td>
        <td>{row.Technology}</td>
        <td>{row.MainValving}</td>
        <td>{row.Rod}</td>
        <td>{row.PT}</td>
        <td>{row.CostCenter}</td>
        <td>{row.ProgramClassification}</td>
        <td>{row.UniqueCode}</td>
        <td>{row.Driv_Plant}</td>
        <td>{row.GlobalAccount}</td>
      </tr>
       
    )});
    console.log(tbdata);

    return reqData;

 }

  return (
    <React.Fragment> 
   

      <div className="content">
        
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle tag="h4">Salesforce</CardTitle>
              </CardHeader>
              <CardBody>

                
        
                <Table className="tablesorter" responsive>
                  <thead className="text-primary">
                    <tr>
                      {/* <th>Numbe</th> */}
                      <th className="text-center">Id</th>
                      <th className="text-center">PLatform Text</th>
                      <th className="text-center">Program Text</th>
                      <th className="text-center">Mounting Location</th>
                      <th className="text-center">Technology</th>
                      <th className="text-center">MainValving</th>
                      <th className="text-center">Rod</th>
                      <th className="text-center">PT</th>	
                      <th className="text-center">CostCenter</th>
                      <th className="text-center">ProgramClassification</th>
                      <th className="text-center">UniqueCode</th>
                      <th className="text-center">Driv_Plant</th>
                      <th className="text-center">GlobalAccount</th>
          
                    </tr>
                  </thead>
                  <tbody className="text-center">
                    {console.log(isDone)}
                    {isDone?showData():null}
                    
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
          
        </Row>
      </div>
      </React.Fragment>
  );
}

export default Tables;// /*!
