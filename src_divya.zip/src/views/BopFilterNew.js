// UserProfile.js
import React, { useState } from "react";
import './barcodecss.css'; 

import {
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
} from "reactstrap";

function BopFilter(props) {
  const {
    plant,
    technology,
    mainValving,
    rod,
    pt,
    filterPlantCallback,
    filterTechnologyCallback,
    filterMainValvingCallback,
    filterRodCallback,
    filterPTCallback,
  } = props;

  const plantOptions = plant.map((val) => (
    <DropdownItem
      key={val}
      href="#pablo"
      onClick={(e) => {
        e.preventDefault();
        filterPlantCallback({ val });
      }}
    >
      {val}
    </DropdownItem>
  ));

  const technologyOptions = technology.map((val) => (
    <DropdownItem
      key={val}
      href="#pablo"
      onClick={(e) => {
        e.preventDefault();
        filterTechnologyCallback({ val });
      }}
    >
      {val}
    </DropdownItem>
  ));

  const mainValvingOptions = mainValving.map((val) => (
    <DropdownItem
      key={val}
      href="#pablo"
      onClick={(e) => {
        e.preventDefault();
        filterMainValvingCallback({ val });
      }}
    >
      {val}
    </DropdownItem>
  ));

  const rodOptions = rod.map((val) => (
    <DropdownItem
      key={val}
      href="#pablo"
      onClick={(e) => {
        e.preventDefault();
        filterRodCallback({ val });
      }}
    >
      {val}
    </DropdownItem>
  ));

  const ptOptions = pt.map((val) => (
    <DropdownItem
      key={val}
      href="#pablo"
      onClick={(e) => {
        e.preventDefault();
        filterPTCallback({ val });
      }}
    >
      {val}
    </DropdownItem>
  ));

  return (
    <div className="MyDropdown">
      <>
        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="GA">
          Global Account

          </DropdownToggle>
          <DropdownMenu>{plantOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="PlatTxt">
          Platform_txt
          </DropdownToggle>
          <DropdownMenu>{technologyOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="Pgtxt">
          Program_txt
          </DropdownToggle>
          <DropdownMenu>{mainValvingOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="ML">
          Mounting Location
          </DropdownToggle>
          <DropdownMenu>{rodOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button"className="Plant">
            Plant
          </DropdownToggle>
          <DropdownMenu>{plantOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="Tech">
            Technology
          </DropdownToggle>
          <DropdownMenu>{technologyOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="MV">
            Main Valving
          </DropdownToggle>
          <DropdownMenu>{mainValvingOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="Rod">
            Rod
          </DropdownToggle>
          <DropdownMenu>{rodOptions}</DropdownMenu>
        </UncontrolledDropdown>

        <UncontrolledDropdown>
          <DropdownToggle caret color="secondary" type="button" className="PT">
            PT
          </DropdownToggle>
          <DropdownMenu>{ptOptions}</DropdownMenu>
        </UncontrolledDropdown>
      </>
    </div>
  );

 }

export default BopFilter;

